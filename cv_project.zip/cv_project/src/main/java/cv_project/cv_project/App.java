package cv_project.cv_project;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;

import org.opencv.calib3d.Calib3d;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.DMatch;
import org.opencv.core.KeyPoint;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfDMatch;
import org.opencv.core.MatOfInt;
import org.opencv.core.MatOfKeyPoint;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.features2d.DescriptorExtractor;
import org.opencv.features2d.DescriptorMatcher;
import org.opencv.features2d.FeatureDetector;
import org.opencv.features2d.Features2d;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.ml.KNearest;
import org.opencv.ml.Ml;
import org.opencv.utils.Converters;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

/**
 * Hello world!
 *
 */
public class App {
	static Boolean use_mask = false;
	static Mat img = null;
	static Mat templ = null;
	static Mat mask = null;

	static int match_method;
	static JLabel imgDisplay = new JLabel();
	static JLabel resultDisplay = new JLabel();
	private static final String VOICENAME_kevin = "kevin";

	public static void main(String[] args) {

		System.out.println("Hello World!");
		String opencvpath = System.getProperty("user.dir") + "\\target\\natives\\";
		String libPath = System.getProperty("java.library.path");
		System.out.println("OpenCv path " + opencvpath);
		System.load(opencvpath + Core.NATIVE_LIBRARY_NAME + ".dll");
		ColorDetection detection = new ColorDetection();
		String x = detection.detectRedColor();
		//x is variable that says if image has red or no.
		//If x is red color, call certain class
		//If x is not red color, call certain class
		
		
		
//		while (true) {
//			img = new Mat();
//			templ = new Mat();
//			mask = new Mat();
//			// TalkResource("Please Start Walking..");
//			// matchTemplate();
//			 detectRedColor();
//			 //textDetection();
//			//ObjectDetection.rectangleDetection();
//			// compare();
//			 //bruteForceMatching();
//			// surfDetector();
//			//horizontallines();
//			try {
//				Thread.sleep(20000L);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
	}

	private static void TalkResource(String sayText) {
		Voice voice;
		VoiceManager voiceManager = VoiceManager.getInstance();
		Voice voices1[] = voiceManager.getVoices();
		// for(Voice v : voices1 )
		{
			System.out.println("No.of.voices" + voices1.length);
			voice = voiceManager.getVoice(VOICENAME_kevin);
			voice.allocate();

			voice.speak(sayText);
		}
	}

	private static void horizontallines() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\horizontal.png";
		Mat source = Imgcodecs.imread(imagePath, Imgcodecs.CV_LOAD_IMAGE_ANYCOLOR);

		Mat destination = new Mat(source.rows(), source.cols(), source.type());
		int threshold = 100;
		Mat edges = new Mat();

		Imgproc.cvtColor(source, destination, Imgproc.COLOR_RGB2GRAY);
		Imgproc.Canny(destination, edges, threshold, threshold * 3);

		Imgproc.equalizeHist(destination, destination);
		Imgproc.GaussianBlur(destination, destination, new Size(5, 5), 0, 0, Core.BORDER_DEFAULT);

		Imgproc.Canny(destination, destination, threshold, threshold * 3);
		Imgproc.adaptiveThreshold(destination, destination, 255, Imgproc.ADAPTIVE_THRESH_MEAN_C, Imgproc.THRESH_BINARY,
				15, 40);
		Imgproc.threshold(destination, destination, 0, 255, Imgproc.THRESH_BINARY);

		if (destination != null) {
			Mat lines = new Mat();
			//Imgproc.HoughLinesP(destination, lines, 1, Math.PI / 180, 50, 30, 10);
			Imgproc.HoughLinesP(destination, lines, 1, Math.PI / 180, 150, 30, 5);
			Mat houghLines = new Mat();
			houghLines.create(destination.rows(), destination.cols(), CvType.CV_8UC1);

			System.out.println("No.of rows" + lines.rows());
			System.out.println("No.of cols" + lines.cols());
			System.out.println("No.of lines" + lines.total());
			for (int i = 0; i < lines.rows(); i++) {
				double[] points = lines.get(i, 0);
				double x1, y1, x2, y2;
				x1 = points[0];
				y1 = points[1];
				x2 = points[2];
				y2 = points[3];

				Point pt1 = new Point(x1, y1);
				Point pt2 = new Point(x2, y2);

				// Drawing lines on an image
				Imgproc.line(source, pt1, pt2, new Scalar(0, 0, 255), 1);
			}

		}

		drawPicture(source);

	}

	private static double angle(Point pt1, Point pt2, Point pt0) {
		double dx1 = pt1.x - pt0.x;
		double dy1 = pt1.y - pt0.y;
		double dx2 = pt2.x - pt0.x;
		double dy2 = pt2.y - pt0.y;
		return (dx1 * dx2 + dy1 * dy2) / Math.sqrt((dx1 * dx1 + dy1 * dy1) * (dx2 * dx2 + dy2 * dy2) + 1e-10);
	}

	private static void drawText(Mat colorImage, Point ofs, String text) {
		Imgproc.putText(colorImage, text, ofs, Core.FONT_HERSHEY_SIMPLEX, 0.5, new Scalar(255, 255, 25));
	}

	private static void surfDetector() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		String templatePath = System.getProperty("user.dir") + "\\src\\main\\resources\\template.png";

		Mat objectImage = Imgcodecs.imread(templatePath, Imgcodecs.CV_LOAD_IMAGE_COLOR);
		Mat sceneImage = Imgcodecs.imread(imagePath, Imgcodecs.CV_LOAD_IMAGE_COLOR);

		MatOfKeyPoint objectKeyPoints = new MatOfKeyPoint();
		FeatureDetector featureDetector = FeatureDetector.create(FeatureDetector.ORB);
		System.out.println("Detecting key points...");
		featureDetector.detect(objectImage, objectKeyPoints);
		KeyPoint[] keypoints = objectKeyPoints.toArray();
		System.out.println(keypoints);

		MatOfKeyPoint objectDescriptors = new MatOfKeyPoint();
		DescriptorExtractor descriptorExtractor = DescriptorExtractor.create(DescriptorExtractor.ORB);
		System.out.println("Computing descriptors...");
		descriptorExtractor.compute(objectImage, objectKeyPoints, objectDescriptors);

		// Create the matrix for output image.
		Mat outputImage = new Mat(objectImage.rows(), objectImage.cols(), Imgcodecs.CV_LOAD_IMAGE_COLOR);
		Scalar newKeypointColor = new Scalar(255, 0, 0);

		System.out.println("Drawing key points on object image...");
		Features2d.drawKeypoints(objectImage, objectKeyPoints, outputImage, newKeypointColor, 0);

		// Match object image with the scene image
		MatOfKeyPoint sceneKeyPoints = new MatOfKeyPoint();
		MatOfKeyPoint sceneDescriptors = new MatOfKeyPoint();
		System.out.println("Detecting key points in background image...");
		featureDetector.detect(sceneImage, sceneKeyPoints);
		System.out.println("Computing descriptors in background image...");
		descriptorExtractor.compute(sceneImage, sceneKeyPoints, sceneDescriptors);

		Mat matchoutput = new Mat(sceneImage.rows() * 2, sceneImage.cols() * 2, Imgcodecs.CV_LOAD_IMAGE_COLOR);
		Scalar matchestColor = new Scalar(0, 255, 0);

		List<MatOfDMatch> matches = new LinkedList<MatOfDMatch>();
		DescriptorMatcher descriptorMatcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE);
		System.out.println("Matching object and scene images...");
		descriptorMatcher.knnMatch(objectDescriptors, sceneDescriptors, matches, 2);

		System.out.println("Calculating good match list...");
		LinkedList<DMatch> goodMatchesList = new LinkedList<DMatch>();

		float nndrRatio = 1.0f;

		for (int i = 0; i < matches.size(); i++) {
			MatOfDMatch matofDMatch = matches.get(i);
			DMatch[] dmatcharray = matofDMatch.toArray();
			DMatch m1 = dmatcharray[0];
			DMatch m2 = dmatcharray[1];

			if (m1.distance <= m2.distance * nndrRatio) {
				goodMatchesList.addLast(m1);

			}
		}

		if (goodMatchesList.size() >= 7) {
			System.out.println("Object Found!!!");

			List<KeyPoint> objKeypointlist = objectKeyPoints.toList();
			List<KeyPoint> scnKeypointlist = sceneKeyPoints.toList();

			LinkedList<Point> objectPoints = new LinkedList<Point>();
			LinkedList<Point> scenePoints = new LinkedList<Point>();

			for (int i = 0; i < goodMatchesList.size(); i++) {
				objectPoints.addLast(objKeypointlist.get(goodMatchesList.get(i).queryIdx).pt);
				scenePoints.addLast(scnKeypointlist.get(goodMatchesList.get(i).trainIdx).pt);
			}

			MatOfPoint2f objMatOfPoint2f = new MatOfPoint2f();
			objMatOfPoint2f.fromList(objectPoints);
			MatOfPoint2f scnMatOfPoint2f = new MatOfPoint2f();
			scnMatOfPoint2f.fromList(scenePoints);

			Mat homography = Calib3d.findHomography(objMatOfPoint2f, scnMatOfPoint2f, Calib3d.RANSAC, 3);

			Mat obj_corners = new Mat(4, 1, CvType.CV_32FC2);
			Mat scene_corners = new Mat(4, 1, CvType.CV_32FC2);

			obj_corners.put(0, 0, new double[] { 0, 0 });
			obj_corners.put(1, 0, new double[] { objectImage.cols(), 0 });
			obj_corners.put(2, 0, new double[] { objectImage.cols(), objectImage.rows() });
			obj_corners.put(3, 0, new double[] { 0, objectImage.rows() });

			System.out.println("Transforming object corners to scene corners...");
			Core.perspectiveTransform(obj_corners, scene_corners, homography);

			Mat img = Imgcodecs.imread(templatePath, Imgcodecs.CV_LOAD_IMAGE_COLOR);

			Imgproc.line(img, new Point(scene_corners.get(0, 0)), new Point(scene_corners.get(1, 0)),
					new Scalar(0, 255, 0), 4);
			Imgproc.line(img, new Point(scene_corners.get(1, 0)), new Point(scene_corners.get(2, 0)),
					new Scalar(0, 255, 0), 4);
			Imgproc.line(img, new Point(scene_corners.get(2, 0)), new Point(scene_corners.get(3, 0)),
					new Scalar(0, 255, 0), 4);
			Imgproc.line(img, new Point(scene_corners.get(3, 0)), new Point(scene_corners.get(0, 0)),
					new Scalar(0, 255, 0), 4);

			System.out.println("Drawing matches image...");
			MatOfDMatch goodMatches = new MatOfDMatch();
			goodMatches.fromList(goodMatchesList);

			Features2d.drawMatches(objectImage, objectKeyPoints, sceneImage, sceneKeyPoints, goodMatches, matchoutput,
					matchestColor, newKeypointColor, new MatOfByte(), 2);

			drawPicture(outputImage);
			drawPicture(matchoutput);
			drawPicture(img);
		}
	}

	private static void bruteForceMatching() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		String templatePath = System.getProperty("user.dir") + "\\src\\main\\resources\\template.png";

		Mat img1 = Imgcodecs.imread(templatePath, Imgcodecs.CV_LOAD_IMAGE_COLOR);
		Mat img2 = Imgcodecs.imread(imagePath, Imgcodecs.CV_LOAD_IMAGE_COLOR);
		FeatureDetector detector = FeatureDetector.create(FeatureDetector.ORB);
		DescriptorExtractor descriptor = DescriptorExtractor.create(DescriptorExtractor.ORB);
		;
		DescriptorMatcher matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE);

		// First photo
		// Imgproc.cvtColor(img1, img1, Imgproc.COLOR_RGB2GRAY);
		Mat descriptors1 = new Mat();
		MatOfKeyPoint keypoints1 = new MatOfKeyPoint();

		detector.detect(img1, keypoints1);
		descriptor.compute(img1, keypoints1, descriptors1);

		// Second photo
		// Imgproc.cvtColor(img2, img2, Imgproc.COLOR_RGB2GRAY);
		Mat descriptors2 = new Mat();
		MatOfKeyPoint keypoints2 = new MatOfKeyPoint();

		detector.detect(img2, keypoints2);
		descriptor.compute(img2, keypoints2, descriptors2);

		MatOfDMatch matches = new MatOfDMatch();
		List<MatOfDMatch> knnmatches = new ArrayList<MatOfDMatch>();
		MatOfDMatch filteredMatches = new MatOfDMatch();
		matcher.match(descriptors1, descriptors2, matches);
		matcher.knnMatch(descriptors1, descriptors2, knnmatches, 2);

		System.out.println("Matches " + knnmatches.size());
		// Linking
		Scalar RED = new Scalar(255, 0, 0);
		Scalar GREEN = new Scalar(0, 255, 0);

		List<DMatch> matchesList = matches.toList();
		Double max_dist = 0.0;
		Double min_dist = 100.0;

		for (int i = 0; i < matchesList.size(); i++) {
			Double dist = (double) matchesList.get(i).distance;
			if (dist < min_dist)
				min_dist = dist;
			if (dist > max_dist)
				max_dist = dist;
		}

		LinkedList<DMatch> good_matches = new LinkedList<DMatch>();
		for (int i = 0; i < matchesList.size(); i++) {
			if (matchesList.get(i).distance <= (4 * min_dist))
				// if (matchesList.get(i).distance <= 10)
				good_matches.addLast(matchesList.get(i));
		}

		// Printing
		MatOfDMatch goodMatches = new MatOfDMatch();
		goodMatches.fromList(good_matches);

		System.out.println(goodMatches.size());

		Mat outputImg = new Mat();
		MatOfByte drawnMatches = new MatOfByte();
		Features2d.drawMatches(img1, keypoints1, img2, keypoints2, goodMatches, outputImg, GREEN, RED, drawnMatches,
				Features2d.NOT_DRAW_SINGLE_POINTS);

		// Highgui.imwrite("matches.png", outputImg);
		drawPicture(outputImg);

	}

	private static void compare(Mat img) {
		// String imagePath = System.getProperty("user.dir") +
		// "\\src\\main\\resources\\trafficlight.png";
		String templatePath = System.getProperty("user.dir") + "\\src\\main\\resources\\template.png";

		// img = Imgcodecs.imread(imagePath, 0);
		templ = Imgcodecs.imread(templatePath, 0);

		Mat imgnew = new Mat();
		Mat templnew = new Mat();

		Imgproc.threshold(img, imgnew, 127, 255, 0);
		Imgproc.threshold(templ, templnew, 127, 255, 0);

		drawPicture(imgnew);
		drawPicture(templnew);

		List<MatOfPoint> imgcontours = new ArrayList<MatOfPoint>();
		List<MatOfPoint> templcontours = new ArrayList<MatOfPoint>();

		Mat hierarchy = new Mat();
		Point offset1 = new Point(0, 0);
		Point offset2 = new Point(0, 0);

		Imgproc.findContours(imgnew, imgcontours, hierarchy, 2, 1, offset1);

		Imgproc.findContours(templnew, templcontours, hierarchy, 2, 1, offset2);

		for (int i = 0; i < imgcontours.size(); i++) {
			Imgproc.drawContours(imgnew, imgcontours, i, new Scalar(255, 255, 255), Core.FILLED);
		}
		for (int i = 0; i < templcontours.size(); i++) {
			Imgproc.drawContours(templnew, templcontours, i, new Scalar(255, 255, 255), Core.FILLED);
		}

		double ret = Imgproc.matchShapes(imgcontours.get(0), templcontours.get(0), 1, 0.0);

		System.out.println("Match ; " + ret);
	}

	private static void compare() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		String templatePath = System.getProperty("user.dir") + "\\src\\main\\resources\\template.png";

		img = Imgcodecs.imread(imagePath, 0);
		templ = Imgcodecs.imread(templatePath, 0);

		Mat imgnew = new Mat();
		Mat templnew = new Mat();

		Imgproc.threshold(img, imgnew, 127, 255, 0);
		Imgproc.threshold(templ, templnew, 127, 255, 0);

		List<MatOfPoint> imgcontours = new ArrayList<MatOfPoint>();
		List<MatOfPoint> templcontours = new ArrayList<MatOfPoint>();

		Mat hierarchy1 = new Mat();
		Mat hierarchy2 = new Mat();
		Point offset1 = new Point(0, 0);
		Point offset2 = new Point(0, 0);

		Imgproc.findContours(imgnew, imgcontours, hierarchy1, 2, 1, offset1);

		Imgproc.findContours(templnew, templcontours, hierarchy2, 2, 1, offset2);

		for (int i = 0; i < imgcontours.size(); i++) {
			Imgproc.drawContours(imgnew, imgcontours, i, new Scalar(255, 0, 0));
		}
		for (int i = 0; i < templcontours.size(); i++) {
			Imgproc.drawContours(templnew, templcontours, i, new Scalar(255, 0, 0));
		}

		drawPicture(imgnew);
		drawPicture(templnew);
		double ret = Imgproc.matchShapes(imgcontours.get(0), templcontours.get(0), 1, 0.0);

		System.out.println("Match ; " + ret);
	}

	private static void textDetection() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\horizontal.png";
		Mat rgb = Imgcodecs.imread(imagePath, 0);
		Mat test = Imgcodecs.imread(imagePath, 0);
		Mat small = new Mat();
		// Imgproc.cvtColor(rgb, small, Imgproc.COLOR_RGB2GRAY);
		Mat grad = new Mat();

		Mat morphKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(3, 3));
		Imgproc.morphologyEx(rgb, grad, Imgproc.MORPH_GRADIENT, morphKernel);

		Mat bw = new Mat();
		Imgproc.threshold(grad, bw, 0.0, 255.0, Imgproc.THRESH_BINARY | Imgproc.THRESH_OTSU);

		Mat connected = new Mat();
		morphKernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(1, 9));
		Imgproc.morphologyEx(bw, connected, Imgproc.MORPH_CLOSE, morphKernel);

		Mat mask = Mat.zeros(bw.size(), CvType.CV_8UC1);
		List<MatOfPoint> contours2 = new ArrayList<MatOfPoint>();
		Mat hierarchy = new Mat();

		Imgproc.findContours(connected, contours2, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE,
				new Point(0, 0));

		List<Rect> txtRect = new ArrayList<Rect>();
		List<MatOfPoint> txtContour = new ArrayList<MatOfPoint>();
		for (int i = 0; i < contours2.size(); i++) {

			Rect rect = Imgproc.boundingRect(contours2.get(i));
			Mat maskROI = new Mat(mask, rect);
			maskROI.setTo(new Scalar(0, 0, 0));
			Imgproc.drawContours(mask, contours2, i, new Scalar(255, 255, 255), Core.FILLED);
			// Imgproc.drawContours(mask, contours2, i, randColor());
			double r = (double) Core.countNonZero(maskROI) / (rect.width * rect.height);

			if (r > .45 && (rect.height > 10 && rect.width > 10)) {

				Imgproc.rectangle(rgb, rect.br(), rect.tl(), randColor());
				txtRect.add(rect);
				txtContour.add(contours2.get(i));
				// Mat auxRoi = new Mat(mask, rect);

			}

		}
		// Mat text = new Mat(rgb.size(), CvType.CV_8U, new Scalar(255));
		// Imgproc.drawContours(text, txtContour, -1, new Scalar(0),
		// Core.FILLED);
		drawPicture(mask);
		// compare(text);

	}

	private static Mat preprocessChar(Mat in) {
		// Remap image
		int h = in.rows();
		int w = in.cols();
		Mat transformMat = Mat.eye(2, 3, CvType.CV_32F);
		int m = Math.max(w, h);
		float value = m / 2 - w / 2;
		transformMat.put(0, 2, value);
		value = m / 2 - h / 2;
		transformMat.put(1, 2, value);
		// transformMat.at<float>(0,2)=m/2 - w/2;
		// transformMat.at<float>(1,2)=m/2 - h/2;

		Mat warpImage = new Mat(m, m, in.type());
		// warpAffine(in, warpImage, transformMat, warpImage.size(),
		// Imgproc.INTER_LINEAR, Imgproc.BORDER_CONSTANT, new Scalar(0) );
		Imgproc.warpAffine(in, warpImage, transformMat, warpImage.size(), Imgproc.INTER_LINEAR, 0, new Scalar(0));

		Mat out = new Mat();
		Imgproc.resize(warpImage, out, new Size(20, 20));

		return out;
	}

	private static void digitDetection() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\numbers.png";
		Mat digits = Imgcodecs.imread(imagePath, 0);
		drawPicture(digits);
		Mat trainData = new Mat(), testData = new Mat();
		Mat num = null;
		List<Integer> trainLabs = new ArrayList<Integer>(), testLabs = new ArrayList<Integer>();
		// 10 digits a 5 rows:
		for (int r = 0; r < 50; r++) {
			// 100 digits per row:
			for (int c = 0; c < 100; c++) {
				// System.out.println("c value " + c);
				// crop out 1 digit:
				try {
					num = digits.submat(new Rect(c * 20, r * 20, 20, 20));
				} catch (Exception e) {

				}
				// we need float data for knn:
				num.convertTo(num, CvType.CV_32F);
				// 50/50 train/test split:
				if (c % 2 == 0) {
					// for opencv ml, each feature has to be a single row:
					trainData.push_back(num.reshape(1, 1));
					// add a label for that feature (the digit number):
					trainLabs.add(r / 5);
				} else {
					testData.push_back(num.reshape(1, 1));
					testLabs.add(r / 5);
				}
			}
		}

		// make a Mat of the train labels, and train knn:
		KNearest knn = KNearest.create();
		knn.train(trainData, Ml.ROW_SAMPLE, Converters.vector_int_to_Mat(trainLabs));
		// now test predictions:
		for (int i = 0; i < testData.rows(); i++) {
			Mat one_feature = testData.row(i);
			int testLabel = testLabs.get(i);

			Mat res = new Mat();
			float p = knn.findNearest(one_feature, 1, res);
			System.out.println(testLabel + "test label " + p + " " + res.dump());
		}

	}

	private static void detectRedColor() {

		System.out.println("Reading File");
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		Mat tmpImage = Imgcodecs.imread(imagePath);
		Mat hsv_image = new Mat();

		Imgproc.cvtColor(tmpImage, hsv_image, Imgproc.COLOR_BGR2HSV);

		Mat lower_red_hue_range = new Mat();
		Mat upper_red_hue_range = new Mat();
		Core.inRange(hsv_image, new Scalar(0, 100, 100), new Scalar(10, 255, 255), lower_red_hue_range);
		Core.inRange(hsv_image, new Scalar(160, 100, 100), new Scalar(179, 255, 255), upper_red_hue_range);

		Mat red_hue_image = new Mat();
		Core.addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0, red_hue_image);

		// Imgproc.GaussianBlur(red_hue_image, red_hue_image, new Size(9, 9), 2,
		// 2);
		drawPicture(red_hue_image);

		for (int i = 0; i < red_hue_image.rows(); i++) {
			for (int j = 0; j < red_hue_image.cols(); j++) {
				double[] rgb = red_hue_image.get(i, j);
				if (rgb[0] == 255)
					System.out.println("Found Red Color");
			}
		}

	}

	private static void detectRedCircles() {

		System.out.println("Reading File");
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		Mat tmpImage = Imgcodecs.imread(imagePath);

		// Check if the image can be loaded

		Mat orig_image = tmpImage.clone();

		Imgproc.medianBlur(tmpImage, tmpImage, 3);

		// Convert input image to HSV
		Mat hsv_image = new Mat();

		Imgproc.cvtColor(tmpImage, hsv_image, Imgproc.COLOR_BGR2HSV);

		// Threshold the HSV image, keep only the red pixels
		Mat lower_red_hue_range = new Mat();
		Mat upper_red_hue_range = new Mat();
		Core.inRange(hsv_image, new Scalar(0, 100, 100), new Scalar(10, 255, 255), lower_red_hue_range);
		Core.inRange(hsv_image, new Scalar(160, 100, 100), new Scalar(179, 255, 255), upper_red_hue_range);

		// Combine the above two images
		Mat red_hue_image = new Mat();
		Core.addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0, red_hue_image);
		drawPicture(red_hue_image);
		Imgproc.GaussianBlur(red_hue_image, red_hue_image, new Size(9, 9), 2, 2);

		// Use the Hough transform to detect circles in the combined threshold
		// image

		Mat circles = new Mat();
		Imgproc.HoughCircles(red_hue_image, circles, Imgproc.CV_HOUGH_GRADIENT, 1, red_hue_image.rows() / 8, 100, 20, 0,
				0);

		// Loop over all detected circles and outline them on the original image
		if (circles.empty()) {
			System.out.println("No red circles");
			// drawContours(orig_image);
			return;
		}
		int size = Integer.valueOf((int) circles.elemSize());
		for (int current_circle = 0; current_circle < size; current_circle++) {
			double[] x = circles.get(current_circle, 0);
			if (x != null) {
				// double[] y = circles.get(current_circle,1);
				// Point center = new Point(x[0], y[0]);
				Point center = new Point(x[0], x[1]);
				// Integer radius =
				// Integer.valueOf(circles.get(current_circle,2).toString());
				Integer radius = (int) x[2];

				Imgproc.circle(orig_image, center, radius, new Scalar(0, 255, 0));
			}
		}
		drawPicture(orig_image);

		// Show images

		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	private static void drawContours(Mat maskedImage) {
		List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
		Mat hierarchy = new Mat();
		Mat frame = new Mat();
		// find contours
		Imgproc.findContours(maskedImage, contours, hierarchy, Imgproc.RETR_CCOMP, Imgproc.CHAIN_APPROX_SIMPLE);

		// if any contour exist...
		if (hierarchy.size().height > 0 && hierarchy.size().width > 0) {
			// for each contour, display it in blue
			for (int idx = 0; idx >= 0; idx = (int) hierarchy.get(0, idx)[0]) {
				Imgproc.drawContours(frame, contours, idx, new Scalar(250, 0, 0));
			}
		}

		drawPicture(frame);

	}

	private static void drawPicture(Mat orig_image) {
		int type = BufferedImage.TYPE_BYTE_GRAY;
		if (orig_image.channels() > 1) {
			type = BufferedImage.TYPE_3BYTE_BGR;
		}

		int bufferSize = orig_image.channels() * orig_image.cols() * orig_image.rows();
		byte[] b = new byte[bufferSize];
		orig_image.get(0, 0, b); // get all the pixels
		BufferedImage image = new BufferedImage(orig_image.cols(), orig_image.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);

		ImageIcon icon = new ImageIcon(image);
		JFrame frame = new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setSize(image.getWidth(null) + 50, image.getHeight(null) + 50);
		JLabel lbl = new JLabel();
		lbl.setIcon(icon);
		frame.add(lbl);
		frame.setVisible(true);
	}

	private static void matchTemplate() {

		// JLabel imgDisplay = new JLabel(), resultDisplay = new JLabel();

		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		String templatePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight_template.png";

		img = Imgcodecs.imread(imagePath, Imgcodecs.IMREAD_COLOR);
		templ = Imgcodecs.imread(templatePath, Imgcodecs.IMREAD_COLOR);

		if (img.empty() || templ.empty() || (use_mask && mask.empty())) {
			System.out.println("Can't read one of the images");
			System.exit(-1);
		}

		matchingMethod();
		createJFrame();

		// read in image default colors
		// System.out.println("Reading File");
		// String imagePath = System.getProperty("user.dir") +
		// "\\src\\main\\resources\\trafficlight.png";
		// Mat sourceColor = Imgcodecs.imread(imagePath);
		// String templatePath = System.getProperty("user.dir") +
		// "\\src\\main\\resources\\trafficlight_template.png";
		//
		// Mat sourceGrey = new Mat(sourceColor.size(), CvType.CV_8UC1);
		// Imgproc.cvtColor(sourceColor, sourceGrey, Imgproc.COLOR_BGR2GRAY);
		// //load in template in grey
		// Mat template =
		// Imgcodecs.imread(templatePath,Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);//int
		// = 0
		//
		// w, h = template.shape[::-1]
		//
		// // Mat template = Imgcodecs.imread(templatePath);//int = 0
		// //Size for the result image
		// Size size = new Size(sourceGrey.cols()-template.cols()+1,
		// sourceGrey.rows()-template.rows()+1);
		// Mat result = new Mat(size, CvType.CV_32FC1);
		// Imgproc.matchTemplate(sourceGrey, template, result,
		// Imgproc.TM_SQDIFF_NORMED);
		// drawPicture(result);
		// double minVal= 0;
		// double maxVal=0;
		// Point min = new Point();
		// Point max = new Point();
		// MinMaxLocResult locSize = Core.minMaxLoc(result);
		// minVal = locSize.minVal;
		// maxVal = locSize.maxVal;
		// Imgproc.rectangle(sourceColor,min,max, randColor());
		//
		// drawPicture( sourceColor);
		// drawPicture( template);
		// drawPicture(result);

	}

	private static Scalar randColor() {
		int b, g, r;
		b = ThreadLocalRandom.current().nextInt(0, 255 + 1);
		g = ThreadLocalRandom.current().nextInt(0, 255 + 1);
		r = ThreadLocalRandom.current().nextInt(0, 255 + 1);
		return new Scalar(b, g, r, 0);
	}

	private static void matchingMethod() {

		Mat result = new Mat();

		Mat img_display = new Mat();
		img.copyTo(img_display);
		int result_cols = 0;
		int result_rows = 0;
		if (img.cols() > templ.cols()) {
			result_cols = img.cols() - templ.cols() + 1;
		} else {
			result_cols = templ.cols() - img.cols() + 1;
		}
		if (img.rows() > templ.rows()) {
			result_rows = img.rows() - templ.rows() + 1;
		} else {
			result_rows = templ.rows() - img.rows() + 1;
		}

		// result.create( result_rows, result_cols, CvType.CV_32FC1 );

		Boolean method_accepts_mask = (Imgproc.TM_SQDIFF == match_method || match_method == Imgproc.TM_CCORR_NORMED
				|| Imgproc.TM_CCOEFF == match_method || Imgproc.TM_CCOEFF_NORMED == match_method
				|| Imgproc.TM_CCORR == match_method || Imgproc.TM_SQDIFF_NORMED == match_method);
		if (use_mask && method_accepts_mask) {
			Imgproc.matchTemplate(img, templ, result, match_method, mask);
		} else {
			Imgproc.matchTemplate(img, templ, result, match_method);
		}

		Core.normalize(result, result, 0, 1, Core.NORM_MINMAX, -1, new Mat());

		double minVal;
		double maxVal;
		Point matchLoc;

		Core.MinMaxLocResult mmr = Core.minMaxLoc(result);

		// For all the other methods, the higher the better
		if (match_method == Imgproc.TM_SQDIFF || match_method == Imgproc.TM_SQDIFF_NORMED) {
			matchLoc = mmr.minLoc;
		} else {
			matchLoc = mmr.maxLoc;
		}

		Imgproc.rectangle(img_display, matchLoc, new Point(matchLoc.x + templ.cols(), matchLoc.y + templ.rows()),
				new Scalar(0, 0, 0), 2, 8, 0);
		Imgproc.rectangle(result, matchLoc, new Point(matchLoc.x + templ.cols(), matchLoc.y + templ.rows()),
				new Scalar(0, 0, 0), 2, 8, 0);

		Image tmpImg = toBufferedImage(img_display);
		ImageIcon icon = new ImageIcon(tmpImg);
		imgDisplay.setIcon(icon);

		result.convertTo(result, CvType.CV_8UC1, 255.0);
		tmpImg = toBufferedImage(result);
		icon = new ImageIcon(tmpImg);
		resultDisplay.setIcon(icon);
	}

	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider) e.getSource();
		if (!source.getValueIsAdjusting()) {
			match_method = (int) source.getValue();
			matchingMethod();
		}
	}

	public static Image toBufferedImage(Mat m) {
		int type = BufferedImage.TYPE_BYTE_GRAY;
		if (m.channels() > 1) {
			type = BufferedImage.TYPE_3BYTE_BGR;
		}
		int bufferSize = m.channels() * m.cols() * m.rows();
		byte[] b = new byte[bufferSize];
		m.get(0, 0, b); // get all the pixels
		BufferedImage image = new BufferedImage(m.cols(), m.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);
		return image;
	}

	private static void createJFrame() {

		String title = "Source image; Control; Result image";
		JFrame frame = new JFrame(title);
		frame.setLayout(new GridLayout(2, 2));
		frame.add(imgDisplay);

		int min = 0, max = 5;
		JSlider slider = new JSlider(JSlider.VERTICAL, min, max, match_method);

		slider.setPaintTicks(true);
		slider.setPaintLabels(true);

		// Set the spacing for the minor tick mark
		slider.setMinorTickSpacing(1);

		// Customizing the labels
		Hashtable labelTable = new Hashtable();
		labelTable.put(new Integer(0), new JLabel("0 - SQDIFF"));
		labelTable.put(new Integer(1), new JLabel("1 - SQDIFF NORMED"));
		labelTable.put(new Integer(2), new JLabel("2 - TM CCORR"));
		labelTable.put(new Integer(3), new JLabel("3 - TM CCORR NORMED"));
		labelTable.put(new Integer(4), new JLabel("4 - TM COEFF"));
		labelTable.put(new Integer(5), new JLabel("5 - TM COEFF NORMED : (Method)"));
		slider.setLabelTable(labelTable);

		// slider.addChangeListener(this);

		// frame.add(slider);

		frame.add(resultDisplay);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}

	private static void findRectangle(Mat src) throws Exception {

		Mat blurred = src.clone();

		Imgproc.medianBlur(src, blurred, 9);

		Mat gray0 = new Mat(blurred.size(), CvType.CV_8U), gray = new Mat();

		List<MatOfPoint> contours = new ArrayList<MatOfPoint>();

		List<Mat> blurredChannel = new ArrayList<Mat>();

		blurredChannel.add(blurred);

		List<Mat> gray0Channel = new ArrayList<Mat>();

		gray0Channel.add(gray0);

		MatOfPoint2f approxCurve;

		double maxArea = 0;

		int maxId = -1;

		for (int c = 0; c < 3; c++) {

			int ch[] = { c, 0 };

			Core.mixChannels(blurredChannel, gray0Channel, new MatOfInt(ch));

			int thresholdLevel = 1;

			for (int t = 0; t < thresholdLevel; t++) {

				if (t == 0) {

					Imgproc.Canny(gray0, gray, 10, 20, 3, true); // true ?

					Imgproc.dilate(gray, gray, new Mat(), new Point(-1, -1), 1); // 1

					// ?

				} else {

					Imgproc.adaptiveThreshold(gray0, gray, thresholdLevel,

							Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,

							Imgproc.THRESH_BINARY,

							(src.width() + src.height()) / 200, t);

				}

				Imgproc.findContours(gray, contours, new Mat(),

						Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);

				for (MatOfPoint contour : contours) {

					MatOfPoint2f temp = new MatOfPoint2f(contour.toArray());

					double area = Imgproc.contourArea(contour);

					approxCurve = new MatOfPoint2f();

					Imgproc.approxPolyDP(temp, approxCurve,

							Imgproc.arcLength(temp, true) * 0.02, true);

					if (approxCurve.total() == 4 && area >= maxArea) {

						double maxCosine = 0;

						List<Point> curves = approxCurve.toList();

						for (int j = 2; j < 5; j++) {

							double cosine = Math.abs(angle(curves.get(j % 4),

									curves.get(j - 2), curves.get(j - 1)));

							maxCosine = Math.max(maxCosine, cosine);

						}

						if (maxCosine < 0.3) {

							maxArea = area;

							maxId = contours.indexOf(contour);

						}

					}

				}

			}

		}

		if (maxId >= 0) {

			Imgproc.drawContours(src, contours, maxId, new Scalar(255, 0, 0,

					.8), 8);

		}
		drawPicture(src);
	}

}

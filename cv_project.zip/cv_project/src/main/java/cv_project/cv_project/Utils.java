package cv_project.cv_project;

import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.Mat;

public class Utils {
	
	public static void drawPicture(Mat orig_image) {
		int type = BufferedImage.TYPE_BYTE_GRAY;
		if (orig_image.channels() > 1) {
			type = BufferedImage.TYPE_3BYTE_BGR;
		}

		int bufferSize = orig_image.channels() * orig_image.cols() * orig_image.rows();
		byte[] b = new byte[bufferSize];
		orig_image.get(0, 0, b); // get all the pixels
		BufferedImage image = new BufferedImage(orig_image.cols(), orig_image.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);

		ImageIcon icon = new ImageIcon(image);
		JFrame frame = new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setSize(image.getWidth(null) + 50, image.getHeight(null) + 50);
		JLabel lbl = new JLabel();
		lbl.setIcon(icon);
		frame.add(lbl);
		frame.setVisible(true);
	}

}

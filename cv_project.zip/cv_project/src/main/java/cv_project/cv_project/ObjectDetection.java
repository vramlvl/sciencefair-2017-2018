package cv_project.cv_project;

import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class ObjectDetection {
	
	public static void rectangleDetection() {
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\horizontal.png";
		Mat rgb = Imgcodecs.imread(imagePath, 0);
		Mat test = Imgcodecs.imread(imagePath, 0);
		Mat small = new Mat();
		// Imgproc.cvtColor(rgb, small, Imgproc.COLOR_RGB2GRAY);
		Mat grad = new Mat();

		Mat morphKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(3, 3));
		Imgproc.morphologyEx(rgb, grad, Imgproc.MORPH_GRADIENT, morphKernel);

		Mat bw = new Mat();
		Imgproc.threshold(grad, bw, 0.0, 255.0, Imgproc.THRESH_BINARY | Imgproc.THRESH_OTSU);

		Mat connected = new Mat();
		morphKernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(1, 9));
		Imgproc.morphologyEx(bw, connected, Imgproc.MORPH_CLOSE, morphKernel);

		Mat mask = Mat.zeros(bw.size(), CvType.CV_8UC1);
		List<MatOfPoint> contours2 = new ArrayList<MatOfPoint>();
		Mat hierarchy = new Mat();

		Imgproc.findContours(connected, contours2, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE,
				new Point(0, 0));

		List<Rect> txtRect = new ArrayList<Rect>();
		List<MatOfPoint> txtContour = new ArrayList<MatOfPoint>();
		for (int i = 0; i < contours2.size(); i++) {

			Rect rect = Imgproc.boundingRect(contours2.get(i));
			Mat maskROI = new Mat(mask, rect);
			maskROI.setTo(new Scalar(0, 0, 0));
			Imgproc.drawContours(mask, contours2, i, new Scalar(255, 255, 255), Core.FILLED);
			// Imgproc.drawContours(mask, contours2, i, randColor());
			double r = (double) Core.countNonZero(maskROI) / (rect.width * rect.height);

			if (r > .45 && (rect.height > 10 && rect.width > 10)) {

				Imgproc.rectangle(rgb, rect.br(), rect.tl(), new Scalar(0,0,255));
				txtRect.add(rect);
				txtContour.add(contours2.get(i));
				

			}

		}
		
		drawPicture(mask);
		

	}
	
	private static void drawPicture(Mat orig_image) {
		int type = BufferedImage.TYPE_BYTE_GRAY;
		if (orig_image.channels() > 1) {
			type = BufferedImage.TYPE_3BYTE_BGR;
		}

		int bufferSize = orig_image.channels() * orig_image.cols() * orig_image.rows();
		byte[] b = new byte[bufferSize];
		orig_image.get(0, 0, b); // get all the pixels
		BufferedImage image = new BufferedImage(orig_image.cols(), orig_image.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);

		ImageIcon icon = new ImageIcon(image);
		JFrame frame = new JFrame();
		frame.setLayout(new FlowLayout());
		frame.setSize(image.getWidth(null) + 50, image.getHeight(null) + 50);
		JLabel lbl = new JLabel();
		lbl.setIcon(icon);
		frame.add(lbl);
		frame.setVisible(true);
	}

}

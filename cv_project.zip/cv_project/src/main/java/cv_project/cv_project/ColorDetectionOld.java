package cv_project.cv_project;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class ColorDetectionOld {
	
	public static void detectRedColor(String imagePath) {

		System.out.println("Reading File");
		imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight_8.png";
		Mat tmpImage = Imgcodecs.imread(imagePath);
		Mat hsv_image = new Mat();

		Imgproc.cvtColor(tmpImage, hsv_image, Imgproc.COLOR_BGR2HSV);

		Mat lower_red_hue_range = new Mat();
		Mat upper_red_hue_range = new Mat();
		
		Core.inRange(hsv_image, new Scalar(0, 100, 100), new Scalar(10, 255, 255), lower_red_hue_range);
		Core.inRange(hsv_image, new Scalar(160, 100, 100), new Scalar(179, 255, 255), upper_red_hue_range);

		Mat red_hue_image = new Mat();
		Core.addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0, red_hue_image);

		// Imgproc.GaussianBlur(red_hue_image, red_hue_image, new Size(9, 9), 2,
		// 2);
		Utils.drawPicture(red_hue_image);

		for (int i = 0; i < red_hue_image.rows(); i++) {
			for (int j = 0; j < red_hue_image.cols(); j++) {
				double[] rgb = lower_red_hue_range.get(i, j);
				if (rgb[0] == 255)
					System.out.println("Found Red Color");
			}
		}

	}

	public static void detectWhiteColor() {

		System.out.println("Reading File");
		String imagePath = System.getProperty("user.dir") + "\\src\\main\\resources\\trafficlight.png";
		Mat tmpImage = Imgcodecs.imread(imagePath);
		Mat hsv_image = new Mat();

		Imgproc.cvtColor(tmpImage, hsv_image, Imgproc.COLOR_BGR2HSV);

		Mat lower_red_hue_range = new Mat();
		Mat upper_red_hue_range = new Mat();
		Core.inRange(hsv_image, new Scalar(0, 100, 100), new Scalar(10, 255, 255), lower_red_hue_range);
		Core.inRange(hsv_image, new Scalar(160, 100, 100), new Scalar(179, 255, 255), upper_red_hue_range);

		Mat red_hue_image = new Mat();
		Core.addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0, red_hue_image);

		// Imgproc.GaussianBlur(red_hue_image, red_hue_image, new Size(9, 9), 2,
		// 2);
		Utils.drawPicture(red_hue_image);

		for (int i = 0; i < red_hue_image.rows(); i++) {
			for (int j = 0; j < red_hue_image.cols(); j++) {
				double[] rgb = lower_red_hue_range.get(i, j);
				if (rgb[0] == 255)
					System.out.println("Found Red Color");
			}
		}

	}
}
